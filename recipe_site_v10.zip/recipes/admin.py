from django.contrib import admin
from modeltranslation.admin import TranslationAdmin
from .models import Recipe, AppointmentHistory  # Make sure to import AppointmentHistory

from .models import AppointmentHistory

class AppointmentHistoryAdmin(admin.ModelAdmin):
    list_display = ('patient_name', 'created_at', 'recorded_by')
    fieldsets = (
        ('Identification Information', {
            'fields': (
                'patient_name', 
                'age', 
                'sex', 
                'occupation', 
                'marital_status', 
                'place_of_residence',
            )
        }),
        ('Reason for Consultation', {
            'fields': (
                'reason_for_consultation',
                'current_symptoms',
                'symptoms_duration',
            )
        }),
        ('Current Illness', {
            'fields': (
                'symptoms_start',
                'symptoms_change',
                'prior_treatment',
                'prior_medical_diagnosis',
                'regular_checkups',
                'complications',
                'food_allergies',
                'medication_allergies',
                'next_appointment',
            )
        }),
        ('Other Information', {
            'fields': (
                'discussion_notes',
                'recorded_by',
            )
        }),
    )
    readonly_fields = ('recorded_by',)

    def save_model(self, request, obj, form, change):
        if not obj.recorded_by:
            obj.recorded_by = request.user
        obj.save()

#admin.site.register(AppointmentHistory, AppointmentHistoryAdmin)

class RecipeAdmin(TranslationAdmin):
     list_display = (
        'name',
        'ingredients',
        'medical_conditions',
        'nutritional_info',
        'cost',
        'image',
        'meal_type',        # ← show this column in the list
    )
     
     fields = (
        'name',
        'ingredients',
        'medical_conditions',
        'nutritional_info',
        'cost',
        'image',
        'meal_type',        # ← this drops in your Breakfast/Lunch/Dinner dropdown
    )
     

admin.site.register(Recipe, RecipeAdmin)

admin.site.register(AppointmentHistory, AppointmentHistoryAdmin)
#admin.site.register(AppointmentHistory, HistoryAdmin)

