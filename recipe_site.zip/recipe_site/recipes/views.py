from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator
from django.db.models import Q  
from .models import Recipe

def recipe_detail(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    return render(request, 'recipes/recipe_detail.html', {'recipe': recipe})

def recipe_list(request):
    query = request.GET.get('query', '')
    medical_condition = request.GET.get('medical_condition', '')

    recipes = Recipe.objects.all()

    all_conditions = Recipe.objects.exclude(medical_conditions="").values_list('medical_conditions', flat=True)
    unique_conditions = sorted(set(all_conditions))

    if query:
        recipes = recipes.filter(
            Q(name__icontains=query) |   
            Q(ingredients__icontains=query) 
        )

    if medical_condition:
        recipes = recipes.filter(medical_conditions__icontains=medical_condition)

    paginator = Paginator(recipes, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'recipes/recipe_list.html', {
        'page_obj': page_obj,
        'medical_conditions': unique_conditions
    })

def calculate_calories(request):
    # Initialize context with empty results
    context = {
        'has_results': False,
        'recipes': Recipe.objects.all()  # Include recipes to maintain list functionality
    }
    
    # Process form submission
    if request.method == 'POST':
        try:
            # Get form data
            gender = request.POST.get('gender')
            height = float(request.POST.get('height', 0))
            weight = float(request.POST.get('weight', 0))
            age = float(request.POST.get('age', 0))
            activity_level = float(request.POST.get('activity_level', 1.2))
            goal = request.POST.get('goal')
            
            # Validate inputs
            if height <= 0 or weight <= 0 or age <= 0:
                context['error'] = "Please enter valid height, weight, and age values."
                context['form_data'] = {
                    'gender': gender,
                    'height': height if height > 0 else '',
                    'weight': weight if weight > 0 else '',
                    'age': age if age > 0 else '',
                    'activity_level': activity_level,
                    'goal': goal
                }
                return render(request, 'recipes/recipe_list.html', context)
            
            # Calculate BMR using Mifflin-St Jeor equation
            if gender == 'male':
                bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5
            else:
                bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161
            
            # Calculate TDEE
            tdee = bmr * activity_level
            
            # Calculate recommended calorie intake based on goal
            if goal == 'loss':
                recommended_calories = tdee - 500  # 500 calorie deficit for weight loss
            elif goal == 'gain':
                recommended_calories = tdee + 300  # 300 calorie surplus for muscle gain
            else:
                recommended_calories = tdee  # Maintenance
            
            # Calculate macronutrient breakdown
            protein_calories = recommended_calories * 0.3
            carbs_calories = recommended_calories * 0.4
            fat_calories = recommended_calories * 0.3
            
            protein_grams = round(protein_calories / 4)
            carbs_grams = round(carbs_calories / 4)
            fat_grams = round(fat_calories / 9)
            
            # Add results to context
            context.update({
                'has_results': True,
                'bmr': round(bmr),
                'tdee': round(tdee),
                'recommended_calories': round(recommended_calories),
                'protein_grams': protein_grams,
                'protein_percent': 30,
                'carbs_grams': carbs_grams,
                'carbs_percent': 40,
                'fat_grams': fat_grams,
                'fat_percent': 30,
                # Keep form data for re-populating the form
                'form_data': {
                    'gender': gender,
                    'height': height,
                    'weight': weight,
                    'age': age,
                    'activity_level': activity_level,
                    'goal': goal
                }
            })
        except (ValueError, TypeError) as e:
            # Handle any conversion errors
            context['error'] = "Please enter valid numeric values for height, weight, and age."
    
    # Apply any search filters from GET parameters to maintain search functionality
    query = request.GET.get('query', '')
    medical_condition = request.GET.get('medical_condition', '')
    
    recipes = Recipe.objects.all()
    
    if query:
        recipes = recipes.filter(
            Q(name__icontains=query) |
            Q(ingredients__icontains=query)
        )
    if medical_condition:
        recipes = recipes.filter(medical_conditions__icontains=medical_condition)
    
    context['recipes'] = recipes
    
    return render(request, 'recipes/recipe_list.html', context)
