from django.contrib import admin
from modeltranslation.admin import TranslationAdmin
from django.urls import path
from django.http import HttpResponse
import docx

from .models import Recipe, AppointmentHistory

@admin.register(AppointmentHistory)
class AppointmentHistoryAdmin(admin.ModelAdmin):
    change_form_template = "admin/recipes/appointmenthistory/change_form.html"

    list_display = (
        'patient_name',
        'created_at',
        'recorded_by',
    )
    fieldsets = (
        ('Identification Information', {
            'fields': (
                'patient_name',
                'age',
                'sex',
                'occupation',
                'marital_status',
                'place_of_residence',
            ),
        }),
        ('Reason for Consultation', {
            'fields': (
                'reason_for_consultation',
                'current_symptoms',
                'symptoms_duration',
            ),
        }),
        ('Current Illness', {
            'fields': (
                'symptoms_start',
                'symptoms_change',
                'prior_treatment',
                'prior_medical_diagnosis',
                'regular_checkups',
                'complications',
                'food_allergies',
                'medication_allergies',
                'next_appointment',
            ),
        }),
        ('Other Information', {
            'fields': (
                'discussion_notes',
                'recorded_by',
            ),
        }),
    )
    readonly_fields = ('recorded_by',)

    def save_model(self, request, obj, form, change):
        if not obj.recorded_by:
            obj.recorded_by = request.user
        obj.save()

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path(
                '<int:pk>/download_docx/',
                self.admin_site.admin_view(self.download_docx),
                name='recipes_appointmenthistory_download_docx'
            ),
        ]
        return custom + urls

    def download_docx(self, request, pk):
        obj = self.get_object(request, pk)
        document = docx.Document()

        # Title
        document.add_heading(f'Appointment for {obj.patient_name}', level=1)
        document.add_paragraph(f"Date: {obj.created_at:%Y-%m-%d %H:%M}")
        document.add_paragraph(f"Recorded by: {obj.recorded_by}")

        # Identification Information
        document.add_heading('Identification Information', level=2)
        document.add_paragraph(f"Patient name: {obj.patient_name}")
        document.add_paragraph(f"Age: {obj.age}")
        document.add_paragraph(f"Sex: {obj.sex}")
        document.add_paragraph(f"Occupation: {obj.occupation}")
        document.add_paragraph(f"Marital status: {obj.marital_status}")
        document.add_paragraph(f"Place of residence: {obj.place_of_residence}")

        # Reason for Consultation
        document.add_heading('Reason for Consultation', level=2)
        document.add_paragraph(f"Reason: {obj.reason_for_consultation or '–'}")
        document.add_paragraph(f"Current symptoms: {obj.current_symptoms or '–'}")
        document.add_paragraph(f"Symptoms duration: {obj.symptoms_duration or '–'}")

        # Current Illness
        document.add_heading('Current Illness', level=2)
        document.add_paragraph(f"Symptoms start: {obj.symptoms_start or '–'}")
        document.add_paragraph(f"Symptoms change: {obj.symptoms_change or '–'}")
        document.add_paragraph(f"Prior treatment: {obj.prior_treatment or '–'}")
        document.add_paragraph(f"Prior medical diagnosis: {obj.prior_medical_diagnosis or '–'}")
        document.add_paragraph(f"Regular checkups: {'Yes' if obj.regular_checkups else 'No'}")
        document.add_paragraph(f"Complications: {obj.complications or '–'}")
        document.add_paragraph(f"Food allergies: {obj.food_allergies or '–'}")
        document.add_paragraph(f"Medication allergies: {obj.medication_allergies or '–'}")
        document.add_paragraph(f"Next appointment: {obj.next_appointment or '–'}")

        # Other Information
        document.add_heading('Other Information', level=2)
        document.add_paragraph(f"Discussion notes: {obj.discussion_notes or '–'}")

        # Stream it back
        resp = HttpResponse(
            content_type=(
                "application/vnd.openxmlformats-officedocument."
                "wordprocessingml.document"
            )
        )
        resp["Content-Disposition"] = f'attachment; filename="appointment_{pk}.docx"'
        document.save(resp)
        return resp


class RecipeAdmin(TranslationAdmin):
    list_display = (
        'name',
        'ingredients',
        'medical_conditions',
        'nutritional_info',
        'cost',
        'image',
        'meal_type',
    )
    fields = list_display  # or expand if needed

admin.site.register(Recipe, RecipeAdmin)
