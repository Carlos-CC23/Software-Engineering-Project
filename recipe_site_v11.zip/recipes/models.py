from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Recipe(models.Model):

    MEAL_TYPE_CHOICES = [
            ('breakfast', 'Breakfast'),
            ('lunch',     'Lunch'),
            ('dinner',    'Dinner'),
    ]

    name = models.CharField(max_length=200)
    ingredients = models.TextField()
    medical_conditions = models.TextField(blank=True, null=True)
    preparation_steps = models.TextField()
    nutritional_info = models.TextField(blank=True, null=True)
    cost = models.CharField(max_length=200, blank=True, null=True)
    image = models.ImageField(upload_to="recipe_images/", blank=True, null=True)


    meal_type = models.CharField(
            max_length=10,
            choices=MEAL_TYPE_CHOICES,
            blank=True,
            null=True,
            verbose_name='Meal category'
        )
    def __str__(self):
        return self.name

class AppointmentHistory(models.Model):
    # --- Basic Identification ---
    patient_name = models.CharField(max_length=100)
    age = models.IntegerField(blank=True, null=True)
    sex = models.CharField(max_length=10, blank=True, null=True)
    occupation = models.CharField(max_length=100, blank=True, null=True)
    marital_status = models.CharField(max_length=50, blank=True, null=True)
    place_of_residence = models.CharField(max_length=200, blank=True, null=True)

    # --- Reason for Consultation ---
    reason_for_consultation = models.TextField(blank=True, null=True)
    current_symptoms = models.TextField(blank=True, null=True)
    symptoms_duration = models.CharField(max_length=100, blank=True, null=True)

    # --- Current Illness ---
    symptoms_start = models.TextField(blank=True, null=True)
    symptoms_change = models.TextField(blank=True, null=True)
    prior_treatment = models.TextField(blank=True, null=True)
    prior_medical_diagnosis = models.TextField(blank=True, null=True)
    regular_checkups = models.BooleanField(default=False)
    complications = models.TextField(blank=True, null=True)
    food_allergies = models.CharField(max_length=200, blank=True, null=True)
    medication_allergies = models.CharField(max_length=200, blank=True, null=True)
    next_appointment = models.CharField(max_length=100, blank=True, null=True)

    # --- System Fields ---
    discussion_notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(default=timezone.now)
    recorded_by = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return f"{self.patient_name} - {self.created_at.strftime('%Y-%m-%d %H:%M')}"
