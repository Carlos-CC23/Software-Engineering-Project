from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator
from django.db.models import Q  
from .models import Recipe
from django.shortcuts import render, redirect #for the appointments
from .forms import AppointmentHistoryForm #importing the forms.py 
from .models import AppointmentHistory 


def recipe_detail(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    return render(request, 'recipes/recipe_detail.html', {'recipe': recipe})

def recipe_list(request):
    query = request.GET.get('query', '')
    medical_condition = request.GET.get('medical_condition', '')

    recipes = Recipe.objects.all()

    all_conditions = Recipe.objects.exclude(medical_conditions="").values_list('medical_conditions', flat=True)
    unique_conditions = sorted(set(all_conditions))

    if query:
        recipes = recipes.filter(
            Q(name__icontains=query) |   
            Q(ingredients__icontains=query) 
        )

    if medical_condition:
        recipes = recipes.filter(medical_conditions__icontains=medical_condition)

    paginator = Paginator(recipes, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'recipes/recipe_list.html', {
        'page_obj': page_obj,
        'medical_conditions': unique_conditions
    })
    
def add_appointment_history(request):
    if request.method == 'POST':
        form = AppointmentHistoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('history_list')
    else:
        form = AppointmentHistoryForm()
    
    return render(request, 'recipes/add_history.html', {'form': form})

def history_list(request):
    histories = AppointmentHistory.objects.all().order_by('-created_at')
    return render(request, 'recipes/history_list.html', {'histories': histories})
    
def calculate_calories(request):
    # Initialize context for calorie results
    context = {
        'has_results': False,
    }
    
    if request.method == 'POST':
        try:
            # Retrieve and convert form data
            gender = request.POST.get('gender')
            height = float(request.POST.get('height', 0))
            weight = float(request.POST.get('weight', 0))
            age = float(request.POST.get('age', 0))
            activity_level = float(request.POST.get('activity_level', 1.2))
            goal = request.POST.get('goal')
            
            # Validate inputs
            if height <= 0 or weight <= 0 or age <= 0:
                context['error'] = "Please enter valid height, weight, and age values."
                context['form_data'] = {
                    'gender': gender,
                    'height': height if height > 0 else '',
                    'weight': weight if weight > 0 else '',
                    'age': age if age > 0 else '',
                    'activity_level': activity_level,
                    'goal': goal
                }
            else:
                # Calculate BMR using the Mifflin-St Jeor equation
                if gender == 'male':
                    bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5
                else:
                    bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161

                # Calculate TDEE
                tdee = bmr * activity_level
                
                # Calculate recommended calorie intake based on goal
                if goal == 'loss':
                    recommended_calories = tdee - 500  # Deficit for weight loss
                elif goal == 'gain':
                    recommended_calories = tdee + 300  # Surplus for muscle gain
                else:
                    recommended_calories = tdee  # Maintenance
                
                # Calculate macronutrient breakdown
                protein_calories = recommended_calories * 0.3
                carbs_calories = recommended_calories * 0.4
                fat_calories = recommended_calories * 0.3
                
                protein_grams = round(protein_calories / 4)
                carbs_grams = round(carbs_calories / 4)
                fat_grams = round(fat_calories / 9)
                
                # Add results to context
                context.update({
                    'has_results': True,
                    'bmr': round(bmr),
                    'tdee': round(tdee),
                    'recommended_calories': round(recommended_calories),
                    'protein_grams': protein_grams,
                    'protein_percent': 30,
                    'carbs_grams': carbs_grams,
                    'carbs_percent': 40,
                    'fat_grams': fat_grams,
                    'fat_percent': 30,
                    'form_data': {
                        'gender': gender,
                        'height': height,
                        'weight': weight,
                        'age': age,
                        'activity_level': activity_level,
                        'goal': goal
                    }
                })
        except (ValueError, TypeError):
            context['error'] = "Please enter valid numeric values for height, weight, and age."
    
    # Apply search filters to maintain recipe list functionality
    query = request.GET.get('query', '')
    medical_condition = request.GET.get('medical_condition', '')
    
    recipes = Recipe.objects.all()
    if query:
        recipes = recipes.filter(
            Q(name__icontains=query) |
            Q(ingredients__icontains=query)
        )
    if medical_condition:
        recipes = recipes.filter(medical_conditions__icontains=medical_condition)
    
    # Get unique medical conditions for filter dropdown
    all_conditions = Recipe.objects.exclude(medical_conditions="").values_list('medical_conditions', flat=True)
    unique_conditions = sorted(set(all_conditions))
    
    # Paginate recipes similar to the recipe_list view
    paginator = Paginator(recipes, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Add recipe list context to our context dictionary
    context['page_obj'] = page_obj
    context['medical_conditions'] = unique_conditions
    
    return render(request, 'recipes/recipe_list.html', context)
