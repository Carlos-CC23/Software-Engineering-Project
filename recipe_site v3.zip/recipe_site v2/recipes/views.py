from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator
from django.db.models import Q  
from .models import Recipe
from django.shortcuts import render, redirect #for the appointments

def recipe_detail(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    return render(request, 'recipes/recipe_detail.html', {'recipe': recipe})

def recipe_list(request):
    query = request.GET.get('query', '')
    medical_condition = request.GET.get('medical_condition', '')

    recipes = Recipe.objects.all()

    all_conditions = Recipe.objects.exclude(medical_conditions="").values_list('medical_conditions', flat=True)
    unique_conditions = sorted(set(all_conditions))

    if query:
        recipes = recipes.filter(
            Q(name__icontains=query) |   
            Q(ingredients__icontains=query) 
        )

    if medical_condition:
        recipes = recipes.filter(medical_conditions__icontains=medical_condition)

    paginator = Paginator(recipes, 9)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'recipes/recipe_list.html', {
        'page_obj': page_obj,
        'medical_conditions': unique_conditions
    })
        
def calculate_calories(request):
    # If someone GET's this URL, bounce them back
    if request.method != 'POST':
        return redirect('recipe_list')

    # 1) Pull form fields
    gender         = request.POST.get('gender')
    height_raw     = request.POST.get('height')
    weight_raw     = request.POST.get('weight')
    age_raw        = request.POST.get('age')
    activity_raw   = request.POST.get('activity_level', 1.2)
    goal           = request.POST.get('goal')

    error   = None
    results = {}
    form_data = {
        'gender': gender,
        'height': height_raw,
        'weight': weight_raw,
        'age': age_raw,
        'activity_level': activity_raw,
        'goal': goal,
    }

    # 2) Compute BMR / TDEE / macros
    try:
        height       = float(height_raw)
        weight       = float(weight_raw)
        age          = float(age_raw)
        activity_lvl = float(activity_raw)

        if height <= 0 or weight <= 0 or age <= 0:
            raise ValueError

        # Mifflin-St Jeor
        if gender == 'male':
            bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5
        else:
            bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161

        tdee = bmr * activity_lvl

        # Goal adjustment
        if goal == 'loss':
            rec = tdee - 500
        elif goal == 'gain':
            rec = tdee + 300
        else:
            rec = tdee

        # Macros
        protein_cal = rec * 0.3
        carbs_cal   = rec * 0.4
        fat_cal     = rec * 0.3

        results = {
            'bmr': round(bmr),
            'tdee': round(tdee),
            'recommended_calories': round(rec),
            'protein_grams': round(protein_cal / 4),
            'carbs_grams':   round(carbs_cal   / 4),
            'fat_grams':     round(fat_cal     / 9),
        }
    except (ValueError, TypeError):
        error = "Please enter valid numeric values for height, weight, and age."

    # 3) Re-run your search/filter/pagination exactly like recipe_list
    q  = request.GET.get('query', '')
    mc = request.GET.get('medical_condition', '')

    recipes = Recipe.objects.all()
    if q:
        recipes = recipes.filter(
            Q(name__icontains=q) | Q(ingredients__icontains=q)
        )
    if mc:
        recipes = recipes.filter(medical_conditions__icontains=mc)

    all_conds       = Recipe.objects.exclude(medical_conditions="")\
                           .values_list('medical_conditions', flat=True)
    unique_conds    = sorted(set(all_conds))

    paginator = Paginator(recipes, 9)             # ← same per-page as recipe_list
    page_obj  = paginator.get_page(request.GET.get('page'))

    # 4) Render back into your main template
    return render(request, 'recipes/recipe_list.html', {
        'page_obj':          page_obj,
        'medical_conditions': unique_conds,
        'error':             error,
        'has_results':       bool(results),
        'results':           results,
        'form_data':         form_data,
    })
